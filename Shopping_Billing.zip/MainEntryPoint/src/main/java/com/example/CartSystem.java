package com.example;

public class CartSystem extends TheSystem {
	CartSystem() {
	}

	@Override
	public void display() {
		System.out.printf("%-20s %-20s %-10s %-10s %-10s\n", "Name", "Description", "Price", "Quantity", "Sub-Total");
		Double preTaxTotal = 0.0d;
		Double tax = 0.0d;
		double total = 0.0d;
		for (Item i : this.getItemCollection().values()) {
			System.out.printf("%-20s %-20s %-10.2f %-10d %-10.2f\n", i.getItemName(), i.getItemDesc(), i.getItemPrice(),
					i.getQuantity(), i.getItemPrice() * i.getQuantity());

			preTaxTotal += (i.getItemPrice() * i.getQuantity());
		}
		System.out.println("\n");
		tax = preTaxTotal * 0.05;
		total = preTaxTotal + tax;
		System.out.printf("%-20s %-20.2f\n", "Pre-tax Total", preTaxTotal);
		System.out.printf("%-20s %-20.2f\n", "Tax", tax);
		System.out.printf("%-20s %-20.2f\n", "Total", total);

		System.out.println("\n");
	}
}
