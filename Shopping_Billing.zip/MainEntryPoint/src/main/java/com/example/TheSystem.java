package com.example;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

public abstract class TheSystem {

	private HashMap<String, Item> itemCollection;

	TheSystem() {
		// Your code here
		this.itemCollection = new HashMap<>();
		if (getClass().getSimpleName().equals("AppSystem")) {
			BufferedReader reader;
			try {
				reader = new BufferedReader(new FileReader("resources/sample.txt"));
				String line = reader.readLine();
				while (line != null) {
					String[] itemInfo = line.split("  ");
					Item item = new Item(itemInfo[0], itemInfo[1], Double.parseDouble(itemInfo[2]),
							Integer.parseInt(itemInfo[3]));
					item.setQuantity(1);
					itemCollection.put(item.getItemName(), item);
					line = reader.readLine();
				}
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public HashMap<String, Item> getItemCollection() {
		return this.itemCollection;
	}

	public Boolean checkAvailability(Item item) {
		if (item.getQuantity() >= item.getAvailableQuantity()) {
			System.out.println("System is unable to add " + item.getItemName() + " to the cart. System only has "
					+ item.getAvailableQuantity() + " " + item.getItemName() + "s.");
			return false;
		}
		return true;
	}

	public Boolean add(Item item) {
		if (item == null) {
			return false;
		}
		if (this.itemCollection.containsKey(item.getItemName())) {
			Item i = this.itemCollection.get(item.getItemName());
			i.setQuantity(i.getQuantity() + 1);
			this.itemCollection.put(i.getItemName(), i);
			return true;
		}
		if (!this.itemCollection.containsKey(item.getItemName())) {
			this.itemCollection.put(item.getItemName(), item);
			return true;
		}

		return false;
	}

	public Item remove(String itemName) {
		if (this.itemCollection.containsKey(itemName)) {
			Item item = this.itemCollection.get(itemName);
			this.itemCollection.remove(itemName);
			return item;
		}

		return null;
	}

	public abstract void display();
}
